# Fuzzy Logic chess game that is going to include an AI
